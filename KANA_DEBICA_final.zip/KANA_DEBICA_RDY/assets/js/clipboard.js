function copyToClipboard() {
    var copyText = document.getElementById("myInput");
    copyText.select();
    document.execCommand("copy");
    alert("Numer telefonu został skopiowany!");
}

function copyToClipboard2() {
    var copyText = document.getElementById("myInput2");
    copyText.select();
    document.execCommand("copy");
    alert("Adres email w twoim schowku!");
}