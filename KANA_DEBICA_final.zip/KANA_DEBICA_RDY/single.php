<!DOCTYPE HTML>
<html>

<head>
	<title>KANA DĘBICA </title>
	<link rel="shortcut icon" href="<?php echo get_template_directory_uri().'/images/favicon.ico'?>" type="image/x-icon">
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri() . '/assets/css/main.css'?>" />
	<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri() . '/assets/css/beneficjenci.css'?>" />
	<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri() . '/assets/css/kadra.css'?>" />
	<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri() . '/assets/css/lokalizacja.css'?>" />
	<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri() . '/assets/css/cookies.css'?>" />

</head>

<body class="is-preload">
	<div id="wrapper">

		<!-- Main -->
		<div id="main">
			<div class="inner">

				<!-- Header -->
				<header id="header">
					<div class="logotypek">
						<img src="http://www.kanadebica.org/wp-content/uploads/2019/07/logo-kana.png">
					</div>
					<a href="http://www.parmba-debica.tarnow.opoka.org.pl/nowa/"
							target="_blank"><img src="<?php echo get_template_directory_uri().'/images/parafia.png'?>" id="parafiaLogo" alt=""  /></a>
				</header>


				<!-- Content -->
				<section>

						<?php if ( have_posts() ) : ?>
	                   		 <?php while ( have_posts() ) : the_post(); ?>    

					<header class="main">
						<h1><?php the_title();?></h1>
						<h3><?php $my_date=get_the_date(); echo $my_date; ?></h3>
					</header>

					<span class="image main"><img src="<?php echo the_post_thumbnail_url();?>" alt="" /></span>

					<p><?php the_content(); ?></p>
					
					<?php endwhile; ?>
					<?php endif; ?>

					<div id="gallery">

					</div>
					<hr class="major" />
					<ul class="actions">
									<li><a href="<?php bloginfo('url');?>" class="button" >Powróć na stronę główną</a></li>
					</ul>


				</section>

			</div>
		</div>

		<!-- Sidebar -->
		<div id="sidebar">
			<div class="inner">

				<!-- Search -->
				<section id="search" class="alt">
					<form method="post" action="#">
						<input type="text" name="query" id="query" placeholder="Wyszukaj" />
					</form>
				</section>

				<!-- Menu -->
				<nav id="menu">
					<header class="major">
						<h2>Menu</h2>
					</header>
					<ul>
						<li class="niebieskiMenu"><a href="<?php bloginfo('url');?>">Strona główna</a></li>
						<li class="zielonyMenu">
							<span class="opener">O Kanie</span>
							<ul>
								<li><a href="/poznaj-kane">Poznaj Kanę!</a></li>

								<li><a href="/kadra/">Kadra </a></li>
								
								<li><a href="/beneficjenci/">Beneficjenci</a></li>
							</ul>
						</li>
						<li class="pomaranczowyMenu">
							<span class="opener">Oferta</span>
							<ul>
								<li><a href="http://www.kanadebica.org/ofertaszpodst/">Szkoła podstawowa</a></li>

								<li><a href="http://www.kanadebica.org/ofertaszpodst/">Szkoła średnia </a>

								<li><a href="http://www.kanadebica.org/ofertaszpodst/">Kursy dla dorosłych </a>

								<li><a href="/category/wykladyotwarte">Wykłady otwarte </a>

								

								
							</ul>
						</li>
						<li class="czerwonyMenu"><a href="/lokalizacja">Lokalizacja</a></li>
						<li class="niebieskiMenu"><a href="#">Kontakt</a></li>
					</ul>
				</nav>

				

				<!-- Footer -->
				<footer id="footer">
					<header class="major">
						<h2>Nasi główni sponsorzy</h2>
					</header>
					<section class="sponsors">
						<a href="http://debica.pl/" class="spons_img" target="_blank"><img src="<?php echo get_template_directory_uri().'/images/miasto.png'?>"
								alt="" target="blank_" class="spons_img" /></a>
						<a href="http://www.powiatdebicki.pl/" class="spons_img" target="_blank"><img
								src="<?php echo get_template_directory_uri().'/images/powiat.png'?>" alt="" class="spons_img"  /></a>
						
						

					</section>
					<hr class="major" />
					<p class="copyright">&copy;Jan Kusek 2019</p>
				</footer>

			</div>
		</div>

	</div>

	<!-- Scripts -->
	<script src="<?php echo get_template_directory_uri().'/assets/js/jquery.min.js'?>"></script>
	<script src="<?php echo get_template_directory_uri().'/assets/js/browser.min.js'?>"></script>
	<script src="<?php echo get_template_directory_uri().'/assets/js/breakpoints.min.js'?>"></script>
	<script src="<?php echo get_template_directory_uri().'/assets/js/util.js'?>"></script>
	<script src="<?php echo get_template_directory_uri().'/assets/js/main.js'?>"></script>
	<script src="<?php echo get_template_directory_uri().'/assets/js/cookies.js'?>"></script>
</body>

</html>