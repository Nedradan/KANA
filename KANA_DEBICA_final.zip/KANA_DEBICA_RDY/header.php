<!DOCTYPE HTML>

<head>
	<title>KANA DĘBICA </title>
	<link rel="shortcut icon" href="<?php echo get_stylesheet_directory_uri() . '/images/favicon.ico'?>" type="image/x-icon">
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri() . '/assets/css/main.css' ?>" />
	<script src="<?php echo get_template_directory_uri().'/assets/js/jquery.min.js'?>"></script>
	<script src="<?php echo get_template_directory_uri().'/assets/js/browser.min.js'?>"></script>
	<script src="<?php echo get_template_directory_uri().'/assets/js/breakpoints.min.js'?>"></script>
	<script src="<?php echo get_template_directory_uri().'/assets/js/util.js'?>"></script>
	<script src="<?php echo get_template_directory_uri().'/assets/js/main.js'?>"></script>


</head>

<body class="is-preload">
	<div id="wrapper">

		<!-- Main -->
		<div id="main">
			<div class="inner">

				<!-- Header -->
				<header id="header">
					<div class="logotypek">
						<img src="<?php echo get_template_directory_uri().'/images/logo kana.PNG'?>" id="kana-logo" style="width:80%;margin-top:0%;">
					</div>
					<a href="http://www.parmba-debica.tarnow.opoka.org.pl/nowa/" class="spons_img"
							target="_blank"><img src="<?php echo get_template_directory_uri().'/images/parafia.png'?>" alt="" style="width:30%; left:45%;top:8%;position:relative;" /></a>
				</header>


				<!-- Banner -->
				<section id="banner">
					<div class="content">
						<div class="zmiany">
							<header class="major">
								<h1>Plan Zajęć</h1>
							</header>
							<a class="image" href="<?php echo get_template_directory_uri().'/images/plan.jpg'?>"><img src="<?php echo get_template_directory_uri().'/images/plan.jpg'?>" alt="" /></a>

							<br>
							<p>Kliknij w obrazek aby zobaczyć plan w pełnej rozdzielczości.</p>
						</div>
						<br>
						<br>

					</div>
					<div class=" content">
						<div class="zmiany">
							<header class="major">
								<h3>ZMIANY W PLANIE ZAJĘĆ</h3>

							</header>
							<p class="ogloszenie">W dniu 29.06 nieobecna będzie Pani Marta.</p>
						</div>
						<div class="zmiany" class="ogloszenie">
							<header class="major">
								<h3>Tutaj jesteśmy!</h3>
							</header>
							<p class="lokalizacja">
								<img src="<?php echo get_template_directory_uri().'/images/kana.PNG'?>" alt="" />
								Katolickie Centrum Edukacji KANA w Dębicy<br>
								Parafia Matki Bożej Anielskiej<br>
								39-200 Dębica, ul. Chopina 2<br>
								Telefon 14 6969-110<br>
								E-mail: kana.debica@wp.pl<br><br>
							</p>
							<div style="clear:both">
								<ul class="actions">
									<li><a href="#" class="button">Zobacz lokalizacje na Mapie Google</a></li>
								</ul>
							</div>


						</div>


					</div>
					<div class="content">
						<div class="zmiany">
							<p class="trzeci_content">
								<br>
								<a href="https://www.facebook.com/debica.kana/"><img src="<?php echo get_template_directory_uri().'/images/fb-logo.png'?>" style="width: 10%;" /></a>
								Odwiedź także nasz profil na Facebooku!
								<br>
							</p>
						</div>
						<div class="zmiany" class="ogloszenie">
							<header class="major">
								<br>

								<h3>I Ty możesz dołożyć cegiełkę do naszego dzieła!</h3>
							</header>
							<p class="trzeci_content">
								<img src="<?php echo get_template_directory_uri().'/images/wesprzyj.png'?>" alt="" />
								<br>Pomóż nam kształcić pokolenia! <br><br>
							</p>
							<div style="clear:both">
								<ul class="actions">
									<li><a href="#" class="button">Chce wesprzeć KANĘ!</a></li>
								</ul>
							</div>

						</div>

					</div>
				</section> 


		