<?php 
add_theme_support('post-thumbnails');
$args = array(
	'name'          => __( 'sidebarr' ),
	'id'            => 'sidebarr',
	'description'   => '',
        'class'         => '',
	'before_widget' => '<p class="ogloszenie">',
	'after_widget'  => '</p>',
	'before_title'  => '<h2>',
	'after_title'   => '</h2>' );

register_sidebar( $args );
?>