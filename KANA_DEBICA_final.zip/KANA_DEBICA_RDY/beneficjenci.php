<!DOCTYPE HTML>
<html>

<head>
	<title>KANA DĘBICA </title>
	<link rel="shortcut icon" href="<?php echo get_template_directory_uri().'/images/favicon.ico'?>"
		type="image/x-icon">
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri() . '/assets/css/main.css'?>" />

</head>

<body class="is-preload">
	<div id="wrapper">

		<!-- Main -->
		<div id="main">
			<div class="inner">

				<!-- Header -->
				<header id="header">
					<div class="logotypek">
						<img src="<?php echo get_template_directory_uri().'/images/logo kana.PNG'?>" id="kana-logo"
							style="width:100%;margin-top:0%;">
					</div>
				</header>

				<!-- Content -->
				<section>
					<header class="main">
						<h1 class="benef_h">Kto może skorzystać na naszych zajęciach?</h1>
						<h1 style="margin-left: 10%;
						color: chocolate;">KAŻDY!</h1>
					</header>

					<span class="image_benef"><img src="<?php echo get_template_directory_uri().'/images/banner03.jpg'?>" alt="" /></span>
					<div class="zmiany1">
						<h3 class="benef"> Dzieci</h3>
						<p> które w ramach projektu – Prowadzenie Centrum Systemowego Rozwoju Dzieci i
							Młodzieży
							mają możliwość korzystania z cyklicznych zajęć z języków obcych (także poprzez zabawę) oraz
							przedmiotowych: z matematyki, informatyki, warsztatów plastycznych i muzycznych. Wszyscy
							mali
							uczestnicy kursów są objęci opieką pedagoga oraz logopedy. Na zajęcia uczęszczają dzieci
							mieszkające na terenie miasta Dębicy w wieku 6-13 lat.</p>

					</div>



					<div class="zmiany2">
						<h3 class="benef2"> Dzieci ze Szkoły podstawowej</h3>
						<p> dla których prowadzone są zajęcia językowe (m.in. niemiecki i
							angielski) oraz przedmiotowe: matematyka, chemia, informatyka, fizyka. Dodatkowo istnieje
							możliwość skorzystania z porad dietetyka i psychologa. Uczniowie, którzy wykazują
							zdolności muzyczne, mogą uczyć się gry na gitarze oraz brać udział w lekcjach śpiewu.
							Wszystkie zajęcia odbywają się w ramach projektu: Prowadzenie Centrum Systemowego Rozwoju
							Dzieci i Młodzieży. Uczestnicy zajęć to uczniowie szkół podstawowych, mieszkających na
							terenie miasta Dębicy.</p>

					</div>



					<div class="zmiany3">
						<h3 class="benef3"> Młodzież ze szkół ponadgimnazjalnych,</h3>
						<p> która uczestnicząc w zajęciach prowadzonych w KANIE, ma możliwość lepszego przygotowania się
							do egzaminu dojrzałości, zarówno na poziomie podstawowym, jak i rozszerzonym, z
							następujących przedmiotów: język angielski, język niemiecki, matematyka, biologia, chemia i
							fizyka, historia, geografia, wos, język polski. Uczestnicy zajęć korzystają dodatkowo ze
							spotkań z psychologiem oraz dietetykiem. Ci, którzy chcą rozwijać się nie tylko
							intelektualnie, mogą brać udział w warsztatach muzycznych. Na zajęcia uczęszczają uczniowie
							szkół ponadgimnazjalnych, mieszkający na terenie powiatu dębickiego w ramach projektu:
							Organizacja zajęć edukacyjnych i wychowawczych dla młodzieży szkół ponadgimnazjalnych
							powiatu dębickiego.</p>

					</div>


					<div class="zmiany4">
						<h3 class="benef4"> Osoby dorosłe</h3>
						<p> czyli wszyscy chętni, którzy ukończyli 18 rok życia i pragną poszerzać swoją
							wiedzę oraz nabywać nowe umiejętności. Dla takich osób KANA prowadzi kursy językowe (m.in.
							język angielski, niemiecki), a także kurs komputerowy, na którym uczestnicy poznają zasady
							pracy z komputerem oraz obsługę podstawowych programów (Word, Excel, Paint).</p>
						<p><u>KANA organizuje także cykliczne wykłady otwarte o różnej tematyce, na które zaprasza
								wszystkich chętnych słuchaczy, niezależnie od wieku.</u></p>
					</div>




				</section>

			</div>
		</div>

		<!-- Sidebar -->
		<div id="sidebar">
			<div class="inner">

				<!-- Search -->
				<section id="search" class="alt">
					<form method="post" action="#">
						<input type="text" name="query" id="query" placeholder="Wyszukaj" />
					</form>
				</section>

				<!-- Menu -->
				<nav id="menu">
					<header class="major">
						<h2>Menu</h2>
					</header>
					<ul>
						<li><a href="index.html">Strona główna</a></li>
						<li><a href="#aktualnosci">Aktualności</a></li>
						<li>
							<span class="opener">O Kanie</span>
							<ul>
								<li><a href="/?page_id=124">Idea i geneza powstania</a></li>

								<li><a href="kadra.php">Kadra </a></li>

								<li><a href="/?page_id=514">Beneficjenci</a></li>

								<li><a href="/?page_id=516">Realizowane projekty</a></li>

								<li><a href="/?page_id=130">Baza dydaktyczna </a></li>
							</ul>
						</li>
						<li>
							<span class="opener">Oferta</span>
							<ul>
								<li><a href="/category/kursypodstawowka">Szkoła podstawowa</a></li>

								<li><a href="/category/kursyponadgimnazjalne">Szkoła średnia </a>

								<li><a href="/category/kursydladoroslych">Kursy dla dorosłych </a>

								<li><a href="/category/wykladyotwarte">Wykłady otwarte </a>

								<li><a href="/category/wypoczynekdzieci">Hobby </a></li>

								<li><a href="/category/konkursy">Konkursy</a></li>

								<li><a href="/category/sapereaude">Nagroda SAPERE AUDE</a></li>
							</ul>
						</li>
						<li><a href="#">Lokalizacja</a></li>
						<li><a href="#">Kontakt</a></li>
					</ul>
				</nav>

				

				<!-- Footer -->
				<footer id="footer">
					<header class="major">
						<h2>Nasi główni sponsorzy</h2>
					</header>
					<section class="sponsors">
						<a href="http://debica.pl/" class="spons_img" target="_blank"><img src="<?php echo get_template_directory_uri().'/images/miasto.png'?>"
								alt="" target="blank_" style="width:35%;" /></a>
						<a href="http://www.powiatdebicki.pl/" class="spons_img" target="_blank"><img
								src="<?php echo get_template_directory_uri().'/images/powiat.png'?>" alt="" style="width:35%;" /></a>
						<a href="http://www.parmba-debica.tarnow.opoka.org.pl/nowa/" class="spons_img"
							target="_blank"><img src="<?php echo get_template_directory_uri().'/images/parafia.png'?>" alt="" style="width:35%;" /></a>
						<a href="https://suret-logistyka.pl/" class="spons_img" target="_blank"><img
								src="<?php echo get_template_directory_uri().'/images/suret.png'?>" alt="" style="width:30%;" /></a>

					</section>

					<p class="copyright">&copy;Jan Kusek 2019</p>
				</footer>

			</div>
		</div>

	</div>

	<!-- Scripts -->
	<script src="<?php echo get_template_directory_uri().'/assets/js/jquery.min.js'?>"></script>
	<script src="<?php echo get_template_directory_uri().'/assets/js/browser.min.js'?>"></script>
	<script src="<?php echo get_template_directory_uri().'/assets/js/breakpoints.min.js'?>"></script>
	<script src="<?php echo get_template_directory_uri().'/assets/js/util.js'?>"></script>
	<script src="<?php echo get_template_directory_uri().'/assets/js/main.js'?>"></script>
	<script src="<?php echo get_template_directory_uri().'/assets/js/gif.js'?>"></script>

</body>

</html>